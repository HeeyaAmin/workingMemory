function fdata = fns_Puddle_rIPS_5ch_LR_inferior
%file (unit) names for 5ch task recorded in Puddle right inferior PPC
% Puddle = monkey A

% !!! NOTE !!!
% Data in the files marked with 'L' and 'R' must be merged before any analysis
% if they are recorded from the same channel on the same day


fdata = { 
%area7   
'Pud20160329La_ch61_1'
'Pud20160329La_ch61_2'
'Pud20160331La_ch61_1'
'Pud20160404La_ch56_1'
'Pud20160404La_ch61_1'
'Pud20160404La_ch61_2'
'Pud20160407La_ch56_1'
'Pud20160329Ra_ch61_1'
'Pud20160329Ra_ch61_2'
'Pud20160331Ra_ch56_1'
'Pud20160331Ra_ch61_1'
'Pud20160404Ra_ch56_1'
'Pud20160404Ra_ch61_1'
'Pud20160404Ra_ch61_2'
'Pud20160407Ra_ch56_1'
%area7/LIP
'Pud20160329La_ch44_1'
'Pud20160329La_ch44_2'
'Pud20160329La_ch45_1'
'Pud20160329La_ch57_1'
'Pud20160331La_ch57_1'
'Pud20160404La_ch44_1'
'Pud20160404La_ch44_2'
'Pud20160404La_ch45_1'
'Pud20160407La_ch51_1'
'Pud20160407La_ch57_1'
'Pud20160407La_ch57_2'
'Pud20160412La_ch44_1'
'Pud20160412La_ch51_1'
'Pud20160329Ra_ch44_1'
'Pud20160329Ra_ch44_2'
'Pud20160329Ra_ch45_1'
'Pud20160329Ra_ch57_1'
'Pud20160331Ra_ch57_1'
'Pud20160404Ra_ch44_1'
'Pud20160404Ra_ch44_2'
'Pud20160404Ra_ch45_1'
'Pud20160407Ra_ch51_1'
'Pud20160407Ra_ch57_1'
'Pud20160407Ra_ch57_2'
'Pud20160412Ra_ch44_1'
'Pud20160412Ra_ch51_1'
'Pud20160331La_ch55_1'
'Pud20160412La_ch55_1'
'Pud20160331Ra_ch55_1'
'Pud20160412Ra_ch55_1'
'Pud20160412Ra_ch43_1'
%area7op
'Pud20160329La_ch60_1'
'Pud20160331La_ch60_1'
'Pud20160404La_ch50_1'
'Pud20160404La_ch60_1'
'Pud20160412La_ch49_1'
'Pud20160412La_ch50_1'
'Pud20160412La_ch60_1'
'Pud20160329Ra_ch60_1'
'Pud20160331Ra_ch50_1'
'Pud20160331Ra_ch60_1'
'Pud20160404Ra_ch50_1'
'Pud20160404Ra_ch60_1'
'Pud20160412Ra_ch49_1'
'Pud20160412Ra_ch50_1'
'Pud20160412Ra_ch60_1'

}



