function fdata = fns_Puddle_rIPS_5ch_LR_superior

%file (unit) names for 5ch task recorded in Puddle right superior PPC
% Puddle = monkey A

% !!! NOTE !!!
% Data in the files marked with 'L' and 'R' must be merged before any analysis
% if they are recorded from the same channel on the same day


fdata = { 
%area5
'Pud20160329La_ch47_1'
'Pud20160329La_ch48_1'
'Pud20160329La_ch48_2'
'Pud20160329La_ch54_1'
'Pud20160331La_ch48_1'
'Pud20160331La_ch54_1'
'Pud20160404La_ch47_1'
'Pud20160404La_ch48_1'
'Pud20160404La_ch54_1'
'Pud20160407La_ch54_1'
'Pud20160412La_ch47_1'
'Pud20160412La_ch48_1'
'Pud20160412La_ch54_1'
'Pud20160329Ra_ch47_1'
'Pud20160329Ra_ch48_1'
'Pud20160329Ra_ch48_2'
'Pud20160329Ra_ch54_1'
'Pud20160331Ra_ch47_1'
'Pud20160331Ra_ch48_1'
'Pud20160331Ra_ch48_2'
'Pud20160331Ra_ch54_1'
'Pud20160404Ra_ch47_1'
'Pud20160404Ra_ch48_1'
'Pud20160404Ra_ch54_1'
'Pud20160407Ra_ch54_1'
'Pud20160412Ra_ch47_1'
'Pud20160412Ra_ch48_1'
'Pud20160412Ra_ch54_1'
%area5/MIP
'Pud20160329La_ch35_1'
'Pud20160329La_ch35_2'
'Pud20160329La_ch39_1'
'Pud20160331La_ch39_1'
'Pud20160404La_ch35_1'
'Pud20160404La_ch39_1'
'Pud20160404La_ch46_1'
'Pud20160412La_ch35_1'
'Pud20160412La_ch39_1'
'Pud20160329Ra_ch35_1'
'Pud20160329Ra_ch35_2'
'Pud20160329Ra_ch39_1'
'Pud20160331Ra_ch35_1'
'Pud20160331Ra_ch39_1'
'Pud20160404Ra_ch35_1'
'Pud20160404Ra_ch39_1'
'Pud20160404Ra_ch46_1'
'Pud20160412Ra_ch35_1'
'Pud20160412Ra_ch39_1'
%area5/MIP/CIP
'Pud20160404La_ch33_1'
'Pud20160412La_ch33_1'
'Pud20160404Ra_ch33_1'
'Pud20160412Ra_ch33_1'
%area5/PCC
'Pud20160329La_ch36_1'
'Pud20160329La_ch37_1'
'Pud20160329La_ch41_1'
'Pud20160331La_ch41_1'
'Pud20160404La_ch36_1'
'Pud20160404La_ch41_1'
'Pud20160412La_ch41_1'
'Pud20160329Ra_ch36_1'
'Pud20160329Ra_ch37_1'
'Pud20160329Ra_ch41_1'
'Pud20160331Ra_ch41_1'
'Pud20160404Ra_ch36_1'
'Pud20160404Ra_ch41_1'
'Pud20160412Ra_ch41_1'
%MIP
'Pud20160329La_ch64_1'
'Pud20160331La_ch58_1'
'Pud20160404La_ch58_1'
'Pud20160329Ra_ch64_1'
'Pud20160331Ra_ch58_1'
'Pud20160331Ra_ch64_1'
'Pud20160404Ra_ch58_1'
}





