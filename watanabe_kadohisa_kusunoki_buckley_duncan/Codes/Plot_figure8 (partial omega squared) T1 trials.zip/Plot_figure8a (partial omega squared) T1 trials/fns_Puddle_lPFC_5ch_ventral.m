function fdata = fns_Puddle_lPFC_5ch_ventral
%file (unit) names for 5ch task recorded in Puddle left ventral PFC
% Puddle = monkey A

fdata = { 
'Pud20150903a_ch02_2'
'Pud20150903a_ch02_1'
'Pud20151009a_ch11_2'
'Pud20151009a_ch11_1'
'Pud20150930a_ch11_1'
'Pud20150914a_ch12_1'
'Pud20151009a_ch12_1'
'Pud20151009a_ch06_1'
'Pud20141204a_ch35_1'
'Pud20141204a_ch35_2'

}

