clear all
width = 100;
slide = 50;
figure()


CD_analysis_win  = [-1000 999];
RESP_analysis_win  = [-1000 599];
FB_analysis_win  = [1 1300];



spacerBin = 10;

Fx_bn= ((CD_analysis_win(2)-CD_analysis_win(1)+1)-width)/slide+1;
Go_bn= ((RESP_analysis_win(2)-RESP_analysis_win(1)+1)-width)/slide+1;
FB_bn= ((FB_analysis_win(2)-FB_analysis_win(1)+1)-width)/slide+1;

%% plot MGS trials
load PEV_MGS_trl_dorsal

PEV_Fx = PEV(:,1:Fx_bn);
PEV_Go = PEV(:,Fx_bn+1 : Fx_bn + Go_bn);
PEV_FB = PEV(:,Fx_bn + Go_bn + 1 : end);

spacer = ones(size(PEV_Fx,1), spacerBin)*NaN;


PEV_all_MGS = horzcat(PEV_Fx, spacer, PEV_Go, spacer, PEV_FB);
PEV_all_MGS_for_stats_vs_EA = horzcat(PEV_Fx, spacer, PEV_Go);
PEV_all_MGS_for_stats_vs_EC_EE = horzcat(PEV_Fx*NaN,spacer, PEV_Go*NaN,spacer,PEV_FB);

FPon = (0 - (CD_analysis_win(1) + width/2)) / slide + 1 %
GoSignal = (0 - (RESP_analysis_win(1) + width/2)) / slide + 1 + 61;
FbOn =  103;
RewOn = (350 - 50)/slide + 1 + 102;


clear PEV_FB PEV_Fx PEV_Go


%%
hold on;
se = nanstd(PEV_all_MGS)/sqrt(size(PEV_all_MGS,1));

plot(1+1 : size(PEV_all_MGS,2) +1, nanmean(PEV_all_MGS),'m-','LineWidth',1.5);
plot(1+1 : size(PEV_all_MGS,2)+1, nanmean(PEV_all_MGS)+se,'m-','LineWidth',0.5);
plot(1+1 : size(PEV_all_MGS,2)+1, nanmean(PEV_all_MGS)-se,'m-','LineWidth',0.5);


plot([FPon + 1, FPon + 1],[-0.005, 0.05],'k')
plot([GoSignal + 1, GoSignal + 1],[-0.005, 0.05],'k')
plot([FbOn + 1, FbOn + 1],[-0.005, 0.05],'k')
plot([RewOn + 1, RewOn + 1],[-0.005, 0.05],'k--')
% FbOn
clear PEV_FB PEV_Fx PEV_Go

%% Stats comparison 1 (MGS vs PEV==0)   Plot significant line by FDR 

Pval = [];
alpha = 0.05;
[cells, bin] = size(PEV_all_MGS);
Baseline = zeros(cells,bin);

for i = 1:bin
    med_MGS = nanmedian(PEV_all_MGS(:,i));
   
    data = horzcat(PEV_all_MGS(:,i),Baseline(:,i));
    
    if  isnan(med_MGS)
         Pval(i) =999;
    else
        for ii = 1:cells
            
            if isnan(data(ii,1))
                data(ii,1) = med_MGS;
            end
            
            
            
           
        end
         dif= data(:,1)-data(:,2);
         pval =mult_comp_perm_t1(dif,10000)
         Pval(i) =  pval;

    end
    clear data
end
hold on;

res = ones(1,bin)*-0.01;

pvalues_cellnum = (find(Pval ~= 999));
spacer_cellnum = (find(Pval == 999));
pvalues = (Pval(pvalues_cellnum));
[h, crit_p, adj_ci_cvrg, adj_p]=fdr_bh(pvalues,0.05,'pdep','yes');
a(pvalues_cellnum) = adj_p
a(spacer_cellnum) = 999;
res(find(a < alpha)) = -0.005;
length(find(a < alpha))

% figure(1)
stairs(1+0.5 : size(PEV_all_MGS,2)+0.5, res,'k','Linewidth',1);%,'m');
