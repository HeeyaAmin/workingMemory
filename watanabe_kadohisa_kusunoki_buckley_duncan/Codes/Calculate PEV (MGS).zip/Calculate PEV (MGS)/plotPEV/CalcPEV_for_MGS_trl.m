clear all
targetnumber = 1;
T_ordr = 1;
IPS = 0;



load kuma_pfc_Correct_trl_MGS
numCells= size(binned_data,2)    % <- SPATIAL���L�^�����j���[�����̌�
PEV = [];
Pval= [];

fn = sprintf('a');

%%-------------------------------------------------------------------------
for i=1:numCells
    i
    SpRateCombined = [];
    IndexMatrix = [];
    
    
        
        trl1 = []; trl2 = []; trl3 = []; trl4 = []; trl3_4 = []; trl5 = [];
        clear idx*
        idx1 = find(binned_labels.touchLocation_ID{i} == 1);
        idx2 = find(binned_labels.touchLocation_ID{i} == 2);
        idx3 = find(binned_labels.touchLocation_ID{i} == 3);
        idx4 = find(binned_labels.touchLocation_ID{i} == 4);
        idx5 = find(binned_labels.touchLocation_ID{i} == 5);
        
        eval(['spikes1',fn,' = binned_data{1,i}(idx1,:);']);
        eval(['spikes2',fn,' = binned_data{1,i}(idx2,:);']);
        eval(['spikes3',fn,' = binned_data{1,i}(idx3,:);']);
        eval(['spikes4',fn,' = binned_data{1,i}(idx4,:);']);
        eval(['spikes5',fn,' = binned_data{1,i}(idx5,:);']);
       
        eval(['SpRateCombined =vertcat(spikes1',fn,',spikes2',fn,' , spikes3',fn,' , spikes4',fn,',spikes5',fn,' );']);
        
        eval(['[trs, bins] =size(spikes1',fn,');']);
        trl1(1:trs) = 1;
        trs = [];
        eval(['[trs, bins] =size(spikes2',fn,');']);
        trl2(1:trs) = 2;
        trs = [];
        eval(['[trs, bins] =size(spikes3',fn,');']);
        trl3(1:trs) = 3;
        trs = [];
        eval(['[trs, bins] =size(spikes4',fn,');']);
        trl4(1:trs) = 4;
        trs = [];
        eval(['[trs, bins] =size(spikes5',fn,');']);
        trl5(1:trs) = 5;
        trs = [];
        
        IndexMatrix = horzcat(trl1,trl2,trl3,trl4,trl5)';
        size(SpRateCombined);
   
    
    for j = 1:bins
        % Simple Effect Analysis of Location at [Corr]
        [p, tbl] = anova1(SpRateCombined(:,j),IndexMatrix ,'off');
        if ~isempty(tbl{10}*(tbl{18}-1)/(tbl{10}*(tbl{18}-1)+ tbl{12}+1))
            
            PEV(i,j)= tbl{10}*(tbl{18}-1)/(tbl{10}*(tbl{18}-1)+ tbl{12}+1);
            Pval(i,j) = p;
            clear tbl p
        else
            PEV(i,j)= NaN;
            Pval(i,j) = NaN;
        end
        %                 [p, tbl] = anova1(SpRateCombined(:,j),IndexMatrix ,'off');
        %                 PEV(i,j)= tbl{10}*(tbl{18}-1)/(tbl{10}*(tbl{18}-1)+ tbl{12}+1);
        %                 Pval(i,j) = p;
        clear tbl p
    end
    
end

save PEV_MGS_trl_dorsal PEV
save Pval_MGS_trl_dorsal Pval




clear pd* spike*



