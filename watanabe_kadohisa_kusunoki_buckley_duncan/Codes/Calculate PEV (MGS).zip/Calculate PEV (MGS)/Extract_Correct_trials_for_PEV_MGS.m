clear all

% reference to data folder
addpath 'C:\Users\�n糁@�c\Documents\MATLAB\Oxford\Pop&Puddle_all'
d = dir('C:\Users\�n糁@�c\Documents\MATLAB\Oxford\Pop&Puddle_all');%Raw �f?[�^�̂���f�B���N�g��

width = 100;
slide = 50;

CD_analysis_win  = [-1000 999];
RESP_analysis_win  = [-1000 599];
FB_analysis_win  = [1 1300];

control_win = [-999 -500];


IPS = 0;
T_ordr = 1; % use data until (T_order =) 1 st correct touch

%%
numBox = 5
lever =1
include_all = 1


if numBox == 5
    targetnumber = [1,2];
elseif numBox == 6
    targetnumber = [1,3];
end

input_cycle = 1

files = [];

for Monkey = 1:1
    if Monkey == 1 && IPS == 0
        if numBox == 5
            files = vertcat(files, fns_monkeyC_lPFC_5ch_all);%, ...
        elseif numBox == 6

        end
    elseif Monkey == 2 && IPS == 0
        if numBox == 5
            
            
        end
    end
end

for include_all  =1:1
    for lever = 1:1
        
        fns = [];
        fnsL = [];
        fnsR = [];
       for i=1:length(files) 
                for ii = 1:length(d)
                    if ~isempty(findstr(files{i},d(ii).name)) 
                        fns = strvcat(fns,d(ii).name); 
                    end
                    if ~isempty(findstr(files{i},d(ii).name)) && ~isempty(findstr('L',d(ii).name))
                        fnsL = strvcat(fnsL,d(ii).name); 
                    end
                    if ~isempty(findstr(files{i},d(ii).name)) && ~isempty(findstr('R',d(ii).name))
                        fnsR = strvcat(fnsR,d(ii).name); 
                    end
                end
            end
        
        [numCells,s] = size(fns);    
        fns
        nstart = 1;
        session_list = [];
        prev_session_name = [];
        session_count = 0;
        counter = 0;
        %%------------------------------------------------------------------------
        for i = nstart:numCells
            
            fn = fns(i,:)
            fname  = fn;
            %%% to append divided files (with _L and _R). Not applicable here.
            load_this = 0;
            if isempty(findstr(fn,'L')) && isempty(findstr(fn,'R'))
                load(fn(1:23)); % load normal session data (non LR condition)
                counter = counter + 1;
                load_this = 1;
                
                load TrialID_List
                load t_trigID
                t_trigID{10} = 'dummy'
                              
                TrialID = vertcat(TrialID_List(1:12), t_code);
                t_trig = vertcat(t_trigID, t_trig);
                
                save(fn,  'fname', 't_spike','t_trig', 'TrialID');
                
            elseif ~isempty(findstr(fn,'R')) % collapse L and R files
                counter = counter + 1;
                load_this = 1;
                t_spike_all = [];
                t_trig_all = [];
                TrialID_all = [];
                fnR = [];
                fnL = [];
                
                fnR = fn;
                load(fnR);
                t_spike_all = t_spike;
                t_trig_all = t_trig;
                TrialID_all = TrialID;
                clear t_spike t_trig TrialID
                
                fnR(findstr(fnR,'R')) = 'L';
                for ii = 1: size(fnsL,1)
                    if ~isempty(findstr(fnR,fnsL(ii,:)))
                        load(fnsL(ii,:))
                        t_spike_all = horzcat(t_spike_all, t_spike);
                        t_trig_all = vertcat(t_trig_all, t_trig(2:end,:));
                        TrialID_all = vertcat(TrialID_all, TrialID(2:end,:));
                        clear t_spike t_trig TrialID
                        break;
                    end
                end
                t_spike = t_spike_all;
                t_trig = t_trig_all;
                TrialID = TrialID_all;
                fn = fnR;
            end
            if load_this
                binned_data{1,counter} = [];
                binned_labels.touchLocation_ID{counter} = [];
                session_name = fname(1,1:12)
                if isempty(prev_session_name) || ~strcmp(prev_session_name,session_name) % new session
                    session_count = session_count + 1
                else
                    session_count = session_count;
                end
                
                if fn(2) == 'u' % puddle
                    excld = 4;
                else
                    excld = 3;
                end
                
                %     1
                % 5       2
                %   4   3
                
                [ec_binspikes ec_target_idx ec_cntl_data]  = bin_spike_4_PEV_Correct_trials_MGS(excld,2,1,t_spike,t_trig,TrialID,width,slide,control_win,CD_analysis_win,RESP_analysis_win,FB_analysis_win,numBox,input_cycle,targetnumber(1),T_ordr,lever,include_all);
                
                
                clear t_spike t_trig TrialID fname
                
                binned_data{1,counter} =ec_binspikes;
                binned_labels.touchLocation_ID{counter} =  ec_target_idx;
                binned_site_info.sessionID(counter) =  session_count;
                
                
                if isempty(prev_session_name) || ~strcmp(prev_session_name,session_name) % new session
                    trial_EC(session_count).val = ec_target_idx;
                end
                prev_session_name = session_name;
                
                clear spike* Corr_then* ec* ce* session_name fn
            end
        end
        
        
        
        if lever
            if include_all
                save kuma_pfc_Correct_trl_MGS binned_data binned_labels binned_site_info trial_EC
            else
                
            end
        else
            if include_all
                
            else
                
            end
        end
    end
end



clear RESP_analysis_win Fx_analysis_win CD_analysis_win control_win IPS T_ordr numBox targetnumber Monkey
clear input_cycle files prev_session_name session_name
