function [binspikes target_idx cntl_data] = bin_spike_4_PEV_Correct_trials_MGS(excld, ...   %location last touched 
    prevFB, ... % Feedback in trial n-1 
    thisFB, ... % FB in trial n
    t_spike_tmp,... %spike time stamps
    t_trig,...  %event time stamps
    TrialID,... %behavioral event codes (eg correct/incorrect)
    width,...   % bin width
    slide,...
    control_win, ...
    Cd_analysis_win, ...
    Resp_analysis_win, ...
    Fb_analysis_win, ...
    numBox,...  % number of choices in the task
    Cycle,...   % cycle to analyze
    targetnumber,... % number of targets in the task
    touchOrder,lev,all_idx)

binspikes = [];
target_idx = [];
cntl_data = [];

w = 30; % Gaussian SD (not used)
Gauss_width = max([11 6*w+1]); % hm, should be an odd number... e.g. 11 (not used)
kernel      = normpdf(-floor(Gauss_width/2):floor(Gauss_width/2),0,w); % not used in this analysis

COI = Cycle;

%%-------------------------------------------------------------------------
% Extract trial event data with Reveal event from raw data (trials appropriate for analyses)
RevealTime = t_trig(2:end,5);
for iii = 1:length(RevealTime)
    if ~isempty(RevealTime{iii}) && length(RevealTime{iii}) == 1
    ActiveTrial(iii) = ~isnan(RevealTime{iii});
    else
        ActiveTrial(iii) = 0;
    end
end

% ��?s���Ƃ�Task���
cellTask = TrialID(2:end,1);
trialcounts = length(cellTask);

% ��?s���Ƃ�touch ID
cellTouchID = TrialID(2:end,9);


% ��?s���Ƃ�TOUCH location
celltcode = TrialID(2:end,7);
for iii = 1:length(celltcode)
    if isempty(celltcode{iii})
        ActiveTrial(iii) = 0;
        celltcode{iii} = NaN;
    end
end


%% ------------------------------------------------------------------------
% ��?s���ƂɃf?[�^���܂Ƃ߂�
trialnum = size(TrialID, 1);
trialnum = trialnum - 1;

 
sps.FB_bin = [];
sps.CD_bin = [];
sps.SAC_bin = [];
sps.REW_bin = [];
sps.All_bin = [];

%% ------------------------------------------------------------------------

trial_count = 0;
if all_idx
    excld = 99;
else
    excld = excld;
end

for i = 1:trialnum
    
    t_spike_in_use{i} = zeros(1,15000);
    ceil(t_spike_tmp{i});
    if ~isempty(t_spike_tmp{i})
        t_spike_in_use{i}(ceil(t_spike_tmp{i})) = 1;
    end

    if   ActiveTrial(i)  == 1 && ...      % Trial i had  Reveal event
         cellTouchID{i}(1)  == 'r' && ... % Trial i is a correct (rewarded trial)
         cellTask{i}     == 4             % Trial i is a MGS task trial

     trial_count = trial_count + 1;
        
        % Extracting CueDelay period activity in 'trial n'
        % set time of data (t_data0 -> t_data1)
        t_range = Cd_analysis_win(2)-Cd_analysis_win(1)+1;  
        bn = (t_range-width)/slide+1;     % number of sliding bins
        t_trig_data = round(t_trig{i+1,3}); % trigger is 3 (memory cue onset)
        
        t_data0 = t_trig_data + Cd_analysis_win(1);
        t_data1 = t_trig_data + Cd_analysis_win(2);
        u_data = zeros(1,t_data1-t_data0+1);
        u_data =  t_spike_in_use{i}(round(t_data0):round(t_data1));

        for j=1:bn
            bs = slide*(j-1)+1;
            be = bs+width-1;            
            u_bin = zeros(1,width);
            u_bin = u_data(1,bs:be);
            sps.CD_bin(trial_count,j) = length(find(u_bin==1)) / (width/1000);  %sum(u_bin); % length(find(u_bin==1));
        end
       
       
        % Extracting Saccade period activity in 'trial n'
        % set time of data (t_data0 -> t_data1)
        t_range = Resp_analysis_win(2)-Resp_analysis_win(1)+1;  
        bn = (t_range-width)/slide+1;     % number of sliding bins
        
        t_trig_data = round(t_trig{i+1,5}); % trigger is 5 (saccade onset);  trigger is 4 (respPeriod onset)
        t_data0 = t_trig_data + Resp_analysis_win(1);
        t_data1 = t_trig_data + Resp_analysis_win(2);
        u_data = zeros(1,t_data1-t_data0+1);
        u_data = t_spike_in_use{i}(round(t_data0):round(t_data1));
        
        for j=1:bn
            bs = slide*(j-1)+1;
            be = bs+width-1;            
            u_bin = zeros(1,width);
            u_bin = u_data(1,bs:be);
            sps.SAC_bin(trial_count,j) = length(find(u_bin==1)) / (width/1000);  %sum(u_bin); % length(find(u_bin==1));
        end
        
        % Extracting Reward period activity in 'trial n'
        % set time of data (t_data0 -> t_data1)
        t_range = Fb_analysis_win(2)-Fb_analysis_win(1)+1;  
        bn = (t_range-width)/slide+1;     % number of sliding bins
        
        t_trig_data = round(t_trig{i+1,6}); % trigger is 6 (reward time);  
        t_data0 = t_trig_data + Fb_analysis_win(1);
        t_data1 = t_trig_data + Fb_analysis_win(2);
        u_data = zeros(1,t_data1-t_data0+1);
        u_data = t_spike_in_use{i}(round(t_data0):round(t_data1));
        
        % Gaussian Kernel Convolution
        % dummy       = conv(u_data,kernel); % pre allocation for speed-up
        % u_data      = dummy(floor(Gauss_width/2)+1:end-floor(Gauss_width/2)); % mode of Gaussian centered on spike -> noncausal      
        for j=1:bn
            bs = slide*(j-1)+1;
            be = bs+width-1;            
            u_bin = zeros(1,width);
            u_bin = u_data(1,bs:be);
            sps.REW_bin(trial_count,j) = length(find(u_bin==1)) / (width/1000);  %sum(u_bin); % length(find(u_bin==1));
        end
        
        
        % identifing location of target (target idx)
        target_idx(trial_count) = celltcode{i};
        
    else
        trial_count = trial_count;
    end
end


%% ------------------------------------------------------------------------
% Creating unified spike data
sps.All_bin = horzcat(sps.CD_bin, sps.SAC_bin, sps.REW_bin);

if trial_count > 0
    binspikes = sps.All_bin;
else
    binspikes = [];
end





