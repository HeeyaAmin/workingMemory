In order to replicate the results in Fig 8 (partial omega PEV),
simply run the script named "Draw_figure8".

