In order to replicate the results in Fig 9 (partial omega PEV),
simply run the script named "Draw_figure9".

